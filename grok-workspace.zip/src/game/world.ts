// @ts-nocheck
import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import type { ControlsProbe } from "./controlsTest";
import type { Layout } from "./layouts";
import { pointInside } from "./layouts";
import type { LevelDef, Quality } from "./types";

export interface InputState {
  moveX: number;
  moveY: number;
  sprint: boolean;
  crouch: boolean;
  flashlight: boolean;
}

export interface FrameInfo {
  nearId: string | null;
  detection: number;
  speed: number;
  yaw: number;
  x: number;
  z: number;
  battery: number;
  caught: number;
}

const PALETTE: Record<LevelDef["palette"], { fog: number; wall: string; floor: string; trim: string }> = {
  cold: { fog: 0x0c1014, wall: "#3c454c", floor: "#2a3036", trim: "#8ea58a" },
  green: { fog: 0x0c110f, wall: "#3e493f", floor: "#2b332c", trim: "#9aaf92" },
  ink: { fog: 0x0a0e14, wall: "#313b48", floor: "#232a33", trim: "#8aa0b4" },
  dust: { fog: 0x12100e, wall: "#4a433c", floor: "#322e2a", trim: "#cbbfa8" },
  zero: { fog: 0x101114, wall: "#3c3e44", floor: "#2a2c31", trim: "#d9d4c8" },
};

interface BoxSpec {
  x: number;
  y: number;
  z: number;
  w: number;
  h: number;
  d: number;
}

function boxGeo(spec: BoxSpec): THREE.BoxGeometry {
  const geo = new THREE.BoxGeometry(spec.w, spec.h, spec.d);
  geo.translate(spec.x, spec.y, spec.z);
  return geo;
}

function mergeBoxes(specs: BoxSpec[]): THREE.BufferGeometry {
  const parts = specs.map(boxGeo);
  const merged = mergeGeometries(parts, false);
  parts.forEach((geo) => geo.dispose());
  if (!merged) throw new Error("geometry merge failed");
  return merged;
}

function makeMap(hex: string, seed: number, wet: boolean): THREE.CanvasTexture {
  const canvas = document.createElement("canvas");
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("canvas");
  ctx.fillStyle = hex;
  ctx.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 2200; i += 1) {
    const x = (seed * 17 + i * 53) % 256;
    const y = (seed * 29 + i * 97) % 256;
    const alpha = 0.03 + ((i + seed) % 12) / 180;
    ctx.fillStyle = `rgba(0,0,0,${alpha})`;
    ctx.fillRect(x, y, wet ? 6 : 2, wet ? 1 : 2);
  }
  ctx.fillStyle = wet ? "rgba(180,190,180,0.05)" : "rgba(10,16,12,0.18)";
  ctx.fillRect(0, wet ? 40 : 170, 256, wet ? 8 : 86);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(wet ? 3 : 2, wet ? 3 : 2);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = 4;
  return tex;
}

function rand(seed: number): () => number {
  let state = seed % 2147483647;
  if (state <= 0) state += 2147483646;
  return () => {
    state = (state * 16807) % 2147483647;
    return (state - 1) / 2147483646;
  };
}

export class GameWorld {
  readonly camera: THREE.PerspectiveCamera;
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private timer = new THREE.Timer();
  private disposed = false;
  private paused = true;
  private exitOpen = false;
  private doorL: THREE.Mesh | null = null;
  private doorR: THREE.Mesh | null = null;
  private threat: THREE.Group | null = null;
  private threatT = 0;
  private lights: { lamp: THREE.PointLight; mesh: THREE.MeshStandardMaterial; phase: number }[] = [];
  private dust: THREE.Points | null = null;
  private shadowPlane: THREE.Mesh | null = null;
  private spot: THREE.SpotLight | null = null;
  private hand: THREE.Group | null = null;
  private keys = new Set<string>();
  private forcedKeys: Set<string> | null = null;
  private lookX = 0;
  private lookY = 0;
  private yaw = 0;
  private pitch = 0;
  private x = 0;
  private z = 0;
  private speed = 0;
  private bob = 0;
  private battery = 100;
  private detection = 0;
  private caught = 0;
  private shake = 0;
  private nearId: string | null = null;
  private lastPush = 0;
  private stepAcc = 0;
  private quietAcc = 0;
  private onKeyDown: (event: KeyboardEvent) => void;
  private onKeyUp: (event: KeyboardEvent) => void;
  private onBlur: () => void;
  private resizeObs: ResizeObserver;
  private tmp = new THREE.Vector3();
  private dir = new THREE.Vector3();

  constructor(
    private canvas: HTMLCanvasElement,
    private level: LevelDef,
    private layout: Layout,
    private quality: Quality,
    private input: () => InputState,
    private onFrame: (info: FrameInfo) => void,
    private onStep: () => void,
    private onDistant: () => void,
    private glove: number,
  ) {
    this.yaw = layout.start.yaw;
    this.x = layout.start.x;
    this.z = layout.start.z;
    const pr = quality === "low" ? 1 : quality === "med" ? Math.min(1.35, window.devicePixelRatio || 1) : Math.min(1.8, window.devicePixelRatio || 1);
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: quality !== "low", powerPreference: "high-performance" });
    this.renderer.setPixelRatio(pr);
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 0.86;
    this.renderer.shadowMap.enabled = quality !== "low";
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.camera = new THREE.PerspectiveCamera(68, 1, 0.08, 70);
    this.camera.rotation.order = "YXZ";
    this.timer.connect(document);
    this.build();
    this.onKeyDown = (event) => {
      this.forcedKeys = null;
      this.keys.add(event.code);
    };
    this.onKeyUp = (event) => {
      this.keys.delete(event.code);
    };
    this.onBlur = () => {
      this.keys.clear();
    };
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
    window.addEventListener("blur", this.onBlur);
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(canvas.parentElement ?? canvas);
    this.resize();
    this.exposeProbe();
    this.renderer.setAnimationLoop(() => this.frame());
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
  }

  setExitOpen(open: boolean): void {
    this.exitOpen = open;
  }

  addLook(dx: number, dy: number, sensitivity: number): void {
    if (this.paused) return;
    const scale = 0.0022 * sensitivity;
    this.lookX += dx * scale;
    this.lookY += dy * scale;
  }

  recharge(): void {
    this.battery = 100;
  }

  destroy(): void {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.timer.disconnect();
    window.removeEventListener("keydown", this.onKeyDown);
    window.removeEventListener("keyup", this.onKeyUp);
    window.removeEventListener("blur", this.onBlur);
    this.resizeObs.disconnect();
    if (window.__controlsTest && window.__controlsTest.getYaw === this.probe.getYaw) {
      delete window.__controlsTest;
    }
    this.scene.traverse((obj) => {
      const mesh = obj as THREE.Mesh;
      if (mesh.geometry) mesh.geometry.dispose();
      const material = mesh.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(material)) material.forEach((item) => disposeMaterial(item));
      else if (material) disposeMaterial(material);
    });
    this.renderer.dispose();
  }

  private probe: ControlsProbe = {
    getYaw: () => this.yaw,
    getSpeed: () => this.speed,
    getPos: () => ({ x: this.x, z: this.z }),
    setKeys: (codes: string[]) => {
      this.forcedKeys = new Set(codes);
    },
    setMove: (x: number, y: number) => {
      this.forcedMove = { x, y };
    },
  };

  private forcedMove: { x: number; y: number } | null = null;

  private exposeProbe(): void {
    const qa = typeof location !== "undefined" && new URLSearchParams(location.search).has("qa");
    if (import.meta.env.DEV || qa) window.__controlsTest = this.probe;
  }

  private resize(): void {
    const parent = this.canvas.parentElement;
    const width = parent?.clientWidth || window.innerWidth;
    const height = parent?.clientHeight || window.innerHeight;
    if (width < 2 || height < 2) return;
    this.renderer.setSize(width, height, false);
    this.camera.aspect = width / Math.max(1, height);
    this.camera.updateProjectionMatrix();
  }

  private build(): void {
    const pal = PALETTE[this.level.palette];
    this.scene.background = new THREE.Color(pal.fog);
    this.scene.fog = new THREE.FogExp2(pal.fog, this.quality === "low" ? 0.085 : 0.055);
    const pmrem = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.05).texture;
    pmrem.dispose();

    const wallTex = makeMap(pal.wall, this.level.id * 3, false);
    const floorTex = makeMap(pal.floor, this.level.id * 5, true);
    const wallMat = new THREE.MeshStandardMaterial({ map: wallTex, roughness: 0.92, metalness: 0.04, color: 0xb7b7b7 });
    const floorMat = new THREE.MeshStandardMaterial({
      map: floorTex,
      roughness: this.quality === "low" ? 0.72 : 0.38,
      metalness: this.quality === "low" ? 0.05 : 0.42,
      color: 0x9a9a9a,
    });
    const ceilMat = new THREE.MeshStandardMaterial({ color: 0x14171a, roughness: 0.95, metalness: 0.02 });
    const propMat = new THREE.MeshStandardMaterial({ color: 0x4a453d, roughness: 0.8, metalness: 0.08 });
    const metalMat = new THREE.MeshStandardMaterial({ color: 0x6d7370, roughness: 0.45, metalness: 0.55 });

    const walls: BoxSpec[] = [];
    const floors: BoxSpec[] = [];
    const ceils: BoxSpec[] = [];
    const height = 3.15;
    const thick = 0.2;
    const step = 0.95;
    for (const rect of this.layout.walk) {
      const cx = (rect.minX + rect.maxX) / 2;
      const cz = (rect.minZ + rect.maxZ) / 2;
      floors.push({ x: cx, y: -0.08, z: cz, w: rect.maxX - rect.minX, h: 0.16, d: rect.maxZ - rect.minZ });
      ceils.push({ x: cx, y: height, z: cz, w: rect.maxX - rect.minX, h: 0.1, d: rect.maxZ - rect.minZ });
      this.edgeWalls(walls, rect.minX, rect.maxX, rect.maxZ, "z", 1, height, thick, step);
      this.edgeWalls(walls, rect.minX, rect.maxX, rect.minZ, "z", -1, height, thick, step);
      this.edgeWalls(walls, rect.minZ, rect.maxZ, rect.minX, "x", -1, height, thick, step);
      this.edgeWalls(walls, rect.minZ, rect.maxZ, rect.maxX, "x", 1, height, thick, step);
    }
    this.addMesh(mergeBoxes(walls), wallMat);
    this.addMesh(mergeBoxes(floors), floorMat);
    this.addMesh(mergeBoxes(ceils), ceilMat);

    const props: BoxSpec[] = [];
    const rng = rand(this.level.id * 97 + 13);
    for (const rect of this.layout.walk) {
      if (rect.maxX - rect.minX < 2.4 || rect.maxZ - rect.minZ < 2.2) continue;
      const px = rect.minX + 0.45;
      const pz = rect.minZ + 0.45;
      if (Math.hypot(px - this.layout.start.x, pz - this.layout.start.z) < 1.6) continue;
      if (this.layout.spots.some((spot) => Math.hypot(spot.x - px, spot.z - pz) < 1.15)) continue;
      props.push({ x: px, y: 0.22, z: pz, w: 0.38 + rng() * 0.25, h: 0.28 + rng() * 0.35, d: 0.32 + rng() * 0.2 });
    }
    if (props.length) this.addMesh(mergeBoxes(props), propMat);
    this.propBlockers = props.map((item) => ({ x: item.x, z: item.z, r: Math.max(item.w, item.d) * 0.48 }));

    for (const spot of this.layout.spots) {
      this.placeProp(spot.id, spot.prop, spot.x, spot.z, propMat, metalMat, pal.trim);
    }

    if (this.level.elevator) {
      const cabin = [
        { x: 0, y: 1.4, z: 6.95, w: 2.4, h: 2.8, d: 0.12 },
        { x: -1.15, y: 1.4, z: 6.2, w: 0.1, h: 2.8, d: 1.5 },
        { x: 1.15, y: 1.4, z: 6.2, w: 0.1, h: 2.8, d: 1.5 },
      ];
      this.addMesh(mergeBoxes(cabin), metalMat);
    }

    this.scene.add(new THREE.HemisphereLight(0x243038, 0x0a0908, 0.62));
    if (this.quality !== "low") {
      const sun = new THREE.DirectionalLight(0xc9d2cf, 0.28);
      sun.position.set(4, 8, 2);
      sun.castShadow = this.quality === "high";
      sun.shadow.mapSize.set(this.quality === "high" ? 1024 : 512, this.quality === "high" ? 1024 : 512);
      this.scene.add(sun);
    }

    const cap = this.quality === "low" ? 2 : this.quality === "med" ? 4 : 6;
    const points = this.lightPoints().slice(0, cap);
    points.forEach((point, index) => {
      const mat = new THREE.MeshStandardMaterial({
        color: pal.trim,
        emissive: pal.trim,
        emissiveIntensity: 0.8,
        roughness: 0.4,
      });
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.06, 0.16), mat);
      mesh.position.set(point.x, 2.95, point.z);
      this.scene.add(mesh);
      const lamp = new THREE.PointLight(0xd7e2d8, 1.1, 9, 1.6);
      lamp.position.set(point.x, 2.75, point.z);
      this.scene.add(lamp);
      this.lights.push({ lamp, mesh: mat, phase: index * 1.7 + this.level.id });
    });

    const spot = new THREE.SpotLight(0xfff3dd, 0, 16, 0.52, 0.5, 1);
    spot.position.set(0.22, -0.22, -0.2);
    const target = new THREE.Object3D();
    target.position.set(0, -0.15, -5);
    this.camera.add(spot);
    this.camera.add(target);
    spot.target = target;
    this.scene.add(this.camera);
    this.spot = spot;

    const hand = new THREE.Group();
    const gloveMat = new THREE.MeshStandardMaterial({ color: this.glove, roughness: 0.7 });
    const palm = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.08, 0.16), gloveMat);
    const flashGeo = new THREE.CylinderGeometry(0.035, 0.04, 0.28, 8);
    flashGeo.rotateX(-Math.PI / 2);
    const flash = new THREE.Mesh(flashGeo, metalMat);
    flash.position.set(0.02, 0.02, -0.12);
    hand.add(palm, flash);
    hand.position.set(0.28, -0.34, -0.5);
    this.camera.add(hand);
    this.hand = hand;

    if (this.quality !== "low") {
      const count = this.quality === "high" ? 110 : 60;
      const positions = new Float32Array(count * 3);
      for (let i = 0; i < count; i += 1) {
        positions[i * 3] = (Math.random() - 0.5) * 1.4;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 1.2;
        positions[i * 3 + 2] = -Math.random() * 4;
      }
      const geo = new THREE.BufferGeometry();
      geo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
      const dust = new THREE.Points(geo, new THREE.PointsMaterial({ color: 0xd9d4c8, size: 0.015, transparent: true, opacity: 0.35 }));
      this.camera.add(dust);
      this.dust = dust;
    }

    if (this.level.threat) {
      const group = new THREE.Group();
      const bodyMat = new THREE.MeshStandardMaterial({ color: 0x07080a, roughness: 0.9, transparent: true, opacity: 0.92 });
      const body = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.34, 1.55, 8), bodyMat);
      body.position.y = 0.95;
      const head = new THREE.Mesh(new THREE.SphereGeometry(0.2, 10, 8), bodyMat);
      head.position.y = 1.85;
      group.add(body, head);
      const p0 = this.layout.threatPath[0];
      if (p0) group.position.set(p0.x, 0, p0.z);
      this.scene.add(group);
      this.threat = group;
    }

    const corner = this.layout.walk[0];
    if (corner) {
      const plane = new THREE.Mesh(
        new THREE.PlaneGeometry(0.7, 1.3),
        new THREE.MeshBasicMaterial({ color: 0x050607, transparent: true, opacity: 0.45, depthWrite: false }),
      );
      plane.position.set(corner.minX + 0.2, 1.1, corner.minZ + 0.35);
      plane.rotation.y = Math.PI / 2;
      this.scene.add(plane);
      this.shadowPlane = plane;
    }
  }

  private propBlockers: { x: number; z: number; r: number }[] = [];

  private addMesh(geo: THREE.BufferGeometry, material: THREE.Material): void {
    const mesh = new THREE.Mesh(geo, material);
    mesh.castShadow = this.quality === "high";
    mesh.receiveShadow = this.quality !== "low";
    this.scene.add(mesh);
  }

  private edgeWalls(out: BoxSpec[], from: number, to: number, edge: number, axis: "x" | "z", outward: number, height: number, thick: number, step: number): void {
    for (let cursor = from; cursor < to - 0.02; cursor += step) {
      const span = Math.min(step, to - cursor);
      const mid = cursor + span / 2;
      const testX = axis === "z" ? mid : edge + outward * 0.38;
      const testZ = axis === "z" ? edge + outward * 0.38 : mid;
      if (pointInside(this.layout, testX, testZ)) continue;
      if (axis === "z") {
        out.push({ x: mid, y: height / 2, z: edge + outward * (thick / 2), w: span + 0.04, h: height, d: thick });
      } else {
        out.push({ x: edge + outward * (thick / 2), y: height / 2, z: mid, w: thick, h: height, d: span + 0.04 });
      }
    }
  }

  private lightPoints(): { x: number; z: number }[] {
    const pts: { x: number; z: number }[] = [];
    for (const rect of this.layout.walk) {
      pts.push({ x: (rect.minX + rect.maxX) / 2, z: (rect.minZ + rect.maxZ) / 2 });
    }
    return pts;
  }

  private placeProp(id: string, prop: Layout["spots"][number]["prop"], x: number, z: number, propMat: THREE.Material, metalMat: THREE.Material, trim: string): void {
    if (prop === "door") {
      const mat = new THREE.MeshStandardMaterial({ color: 0x22262a, roughness: 0.6, metalness: 0.3, emissive: 0x1a2420, emissiveIntensity: 0.15 });
      const left = new THREE.Mesh(new THREE.BoxGeometry(0.62, 2.4, 0.08), mat);
      const right = new THREE.Mesh(new THREE.BoxGeometry(0.62, 2.4, 0.08), mat);
      left.position.set(x - 0.34, 1.2, z - 0.35);
      right.position.set(x + 0.34, 1.2, z - 0.35);
      this.scene.add(left, right);
      this.doorL = left;
      this.doorR = right;
      return;
    }
    const group = new THREE.Group();
    if (prop === "desk" || prop === "paper") {
      const top = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.06, 0.42), propMat);
      top.position.y = 0.72;
      const leg = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.7, 0.08), propMat);
      leg.position.set(-0.28, 0.35, -0.16);
      const sheetMat = new THREE.MeshStandardMaterial({ color: 0xe6e1d6, roughness: 0.9 });
      const sheet = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.01, 0.2), sheetMat);
      sheet.position.set(0.05, 0.76, 0);
      group.add(top, leg, sheet);
    } else if (prop === "phone") {
      const stand = new THREE.Mesh(new THREE.BoxGeometry(0.28, 0.5, 0.28), propMat);
      stand.position.y = 0.25;
      const setMat = new THREE.MeshStandardMaterial({ color: 0x1c1f18, emissive: trim, emissiveIntensity: 0.4, roughness: 0.5 });
      const handset = new THREE.Mesh(new THREE.BoxGeometry(0.16, 0.05, 0.08), setMat);
      handset.position.y = 0.53;
      group.add(stand, handset);
    } else if (prop === "panel" || prop === "pedestal") {
      const box = new THREE.Mesh(new THREE.BoxGeometry(0.34, prop === "pedestal" ? 1.05 : 0.7, 0.16), metalMat);
      box.position.y = prop === "pedestal" ? 0.52 : 1.15;
      const ledMat = new THREE.MeshStandardMaterial({ color: trim, emissive: trim, emissiveIntensity: 0.9 });
      const led = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.06, 0.02), ledMat);
      led.position.set(0, box.position.y + 0.2, 0.09);
      group.add(box, led);
    } else if (prop === "locker") {
      const locker = new THREE.Mesh(new THREE.BoxGeometry(0.55, 1.9, 0.4), metalMat);
      locker.position.set(0.35, 0.95, 0);
      group.add(locker);
    }
    group.position.set(x, 0, z);
    this.scene.add(group);
    if (id === "exit") {
      /* door handled above */
    }
  }

  private blocked(x: number, z: number): boolean {
    if (!pointInside(this.layout, x, z)) return true;
    return this.propBlockers.some((item) => Math.hypot(item.x - x, item.z - z) < item.r);
  }

  private tryMove(nx: number, nz: number): void {
    if (!this.blocked(nx, this.z)) this.x = nx;
    if (!this.blocked(this.x, nz)) this.z = nz;
  }

  private frame(): void {
    if (this.disposed) return;
    this.timer.update();
    const raw = Math.min(this.timer.getDelta(), 0.1);
    const dt = this.paused ? 0 : raw;
    const input = this.input();
    const keys = this.forcedKeys ?? this.keys;
    let fwd = this.forcedMove ? this.forcedMove.y : input.moveY;
    let strafe = this.forcedMove ? this.forcedMove.x : input.moveX;
    if (keys.has("KeyW") || keys.has("ArrowUp")) fwd += 1;
    if (keys.has("KeyS") || keys.has("ArrowDown")) fwd -= 1;
    if (keys.has("KeyD") || keys.has("ArrowRight")) strafe += 1;
    if (keys.has("KeyA") || keys.has("ArrowLeft")) strafe -= 1;
    fwd = Math.max(-1, Math.min(1, fwd));
    strafe = Math.max(-1, Math.min(1, strafe));
    this.yaw -= this.lookX;
    this.pitch -= this.lookY;
    this.lookX = 0;
    this.lookY = 0;
    this.pitch = Math.max(-1.15, Math.min(1.15, this.pitch));

    const sprint = input.sprint || keys.has("ShiftLeft") || keys.has("ShiftRight");
    const crouch = input.crouch;
    const movingIntent = Math.hypot(fwd, strafe) > 0.08;
    let speed = crouch ? 1.15 : sprint && movingIntent ? 3.65 : 2.3;
    if (!movingIntent) speed = 0;
    const fx = -Math.sin(this.yaw);
    const fz = -Math.cos(this.yaw);
    const rx = Math.cos(this.yaw);
    const rz = -Math.sin(this.yaw);
    const len = Math.hypot(fwd, strafe) || 1;
    const nx = this.x + ((fx * fwd + rx * strafe) / len) * speed * dt;
    const nz = this.z + ((fz * fwd + rz * strafe) / len) * speed * dt;
    if (dt > 0) this.tryMove(nx, nz);
    this.speed = dt > 0 ? Math.hypot(this.x - (nx - ((fx * fwd + rx * strafe) / len) * speed * dt), 0) : 0;
    const actual = speed > 0 && (this.x !== nx || this.z !== nz || !this.blocked(nx, nz)) ? speed * Math.min(1, Math.hypot(fwd, strafe)) : 0;
    this.speed = actual;

    if (input.flashlight && this.battery > 0) this.battery = Math.max(0, this.battery - dt * 1.15);
    const lightOn = input.flashlight && this.battery > 0.5;
    if (this.spot) {
      const flicker = this.battery < 18 ? 0.45 + Math.abs(Math.sin(this.timer.getElapsed() * 30)) * 0.55 : 1;
      this.spot.intensity = lightOn ? 6.5 * flicker : 0;
    }
    if (this.hand) {
      this.bob += dt * (actual > 0.2 ? 9 : 0);
      this.hand.position.y = -0.34 + Math.sin(this.bob) * (actual > 0.2 ? 0.02 : 0);
    }
    if (this.dust) this.dust.visible = lightOn;

    const elapsed = this.timer.getElapsed();
    for (const light of this.lights) {
      const dip = Math.sin(elapsed * (1.4 + (light.phase % 3)) + light.phase) > 0.93 ? 0.15 : 1;
      const glow = 0.45 + 0.55 * (0.5 + 0.5 * Math.sin(elapsed * 6 + light.phase));
      light.lamp.intensity = 1.35 * glow * dip;
      light.mesh.emissiveIntensity = 0.35 + glow * dip;
    }

    if (this.doorL && this.doorR) {
      const target = this.exitOpen ? 1.05 : 0.34;
      this.doorL.position.x += (this.layout.spots.find((s) => s.id === "exit")!.x - target - this.doorL.position.x) * Math.min(1, dt * 4);
      this.doorR.position.x += (this.layout.spots.find((s) => s.id === "exit")!.x + target - this.doorR.position.x) * Math.min(1, dt * 4);
      const mat = this.doorL.material as THREE.MeshStandardMaterial;
      mat.emissive.set(this.exitOpen ? 0x8ea58a : 0x1a2420);
      mat.emissiveIntensity = this.exitOpen ? 0.55 : 0.12;
    }

    this.updateThreat(dt, sprint, crouch, lightOn);
    this.updateShadow();

    const eye = (crouch ? 1.02 : 1.58) + Math.sin(this.bob) * 0.025;
    this.shake = Math.max(0, this.shake - dt * 1.4);
    this.camera.position.set(this.x + (this.shake > 0 ? Math.sin(elapsed * 40) * 0.03 * this.shake : 0), eye, this.z);
    this.camera.rotation.y = this.yaw;
    this.camera.rotation.x = this.pitch;

    if (actual > 0.4) {
      this.stepAcc += dt * (sprint ? 2.6 : 1.8);
      if (this.stepAcc > 1) {
        this.stepAcc = 0;
        this.onStep();
      }
    } else {
      this.quietAcc += dt;
      if (this.quietAcc > 28) {
        this.quietAcc = 0;
        this.onDistant();
      }
    }

    let near: string | null = null;
    let best = 1.7;
    for (const spot of this.layout.spots) {
      const dist = Math.hypot(spot.x - this.x, spot.z - this.z);
      if (dist < best) {
        best = dist;
        near = spot.id;
      }
    }
    this.nearId = near;
    const now = elapsed;
    if (now - this.lastPush > 0.08 || near !== this.lastNearPush) {
      this.lastPush = now;
      this.lastNearPush = near;
      this.onFrame({
        nearId: near,
        detection: this.detection,
        speed: actual,
        yaw: this.yaw,
        x: this.x,
        z: this.z,
        battery: this.battery,
        caught: this.caught,
      });
    }
    this.renderer.render(this.scene, this.camera);
  }

  private lastNearPush: string | null = null;

  private updateThreat(dt: number, sprint: boolean, crouch: boolean, lightOn: boolean): void {
    const threat = this.level.threat;
    if (!threat || !this.threat || dt === 0) return;
    const path = this.layout.threatPath;
    if (path.length < 2) return;
    this.threatT += dt * 0.16;
    const span = path.length;
    const loop = this.threatT % span;
    const index = Math.floor(loop) % span;
    const next = (index + 1) % span;
    const t = loop - Math.floor(loop);
    const a = path[index]!;
    const b = path[next]!;
    const tx = a.x + (b.x - a.x) * t;
    const tz = a.z + (b.z - a.z) * t;
    this.threat.position.x = tx;
    this.threat.position.z = tz;
    this.threat.lookAt(b.x, 0, b.z);
    const dist = Math.hypot(tx - this.x, tz - this.z);
    let gain = 0;
    if (threat.kind === "sound" || threat.kind === "both") {
      if (sprint && dist < 8) gain = Math.max(gain, 0.72);
      else if (this.speed > 0.3 && dist < 2.3) gain = Math.max(gain, 0.18);
    }
    if (threat.kind === "light" || threat.kind === "both") {
      if (lightOn && dist < 8.5) gain = Math.max(gain, 0.8);
    }
    if (threat.kind === "presence") {
      const cover = this.inCover(crouch);
      if (!cover && dist < 5.6) gain = Math.max(gain, 0.62);
    }
    if ((threat.kind === "sound" || threat.kind === "both" || threat.kind === "light") && this.inCover(crouch) && dist > 1.2) {
      gain *= 0.25;
    }
    if (gain > 0) this.detection = Math.min(1, this.detection + gain * dt);
    else this.detection = Math.max(0, this.detection - 0.22 * dt);
    const mat = (this.threat.children[0] as THREE.Mesh).material as THREE.MeshStandardMaterial;
    mat.opacity = 0.55 + this.detection * 0.4;
    if (this.detection >= 1) {
      this.detection = 0;
      this.x = this.layout.start.x;
      this.z = this.layout.start.z;
      this.yaw = this.layout.start.yaw;
      this.caught += 1;
      this.shake = 1;
    }
  }

  private inCover(crouch: boolean): boolean {
    if (!crouch) return false;
    return this.layout.spots.some((spot) => (spot.id === "cover1" || spot.id === "cover2") && Math.hypot(spot.x - this.x, spot.z - this.z) < 1.35);
  }

  private updateShadow(): void {
    if (!this.shadowPlane) return;
    this.shadowPlane.getWorldPosition(this.tmp);
    this.camera.getWorldDirection(this.dir);
    this.tmp.sub(this.camera.position).setY(0);
    if (this.tmp.lengthSq() < 0.001) return;
    this.tmp.normalize();
    const facing = this.tmp.dot(this.dir.setY(0).normalize());
    const mat = this.shadowPlane.material as THREE.MeshBasicMaterial;
    mat.opacity = facing > 0.86 ? 0.04 : 0.42;
  }
}

function disposeMaterial(material: THREE.Material): void {
  const mapped = material as THREE.MeshStandardMaterial;
  mapped.map?.dispose();
  material.dispose();
}

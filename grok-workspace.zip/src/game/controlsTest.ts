export interface ControlsProbe {
  getYaw: () => number;
  getSpeed: () => number;
  getPos: () => { x: number; z: number };
  setKeys: (codes: string[]) => void;
  setMove: (x: number, y: number) => void;
}

declare global {
  interface Window {
    __controlsTest?: ControlsProbe;
    __avida?: {
      startLevel: (id: number) => void;
      screen: () => string;
    };
  }
}

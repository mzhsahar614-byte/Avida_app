import type { LayoutId } from "./types";

export interface WalkRect {
  minX: number;
  maxX: number;
  minZ: number;
  maxZ: number;
}

export type PropKind = "desk" | "phone" | "panel" | "locker" | "door" | "paper" | "pedestal";

export interface SpotDef {
  id: string;
  x: number;
  z: number;
  prop: PropKind;
}

export interface Layout {
  id: LayoutId;
  walk: WalkRect[];
  spots: SpotDef[];
  start: { x: number; z: number; yaw: number };
  threatPath: { x: number; z: number }[];
}

function hall(): Layout {
  return {
    id: "hall",
    walk: [
      { minX: -1.7, maxX: 1.7, minZ: -14.8, maxZ: 7.2 },
      { minX: -5.3, maxX: -1.7, minZ: -3.8, maxZ: -0.4 },
      { minX: 1.7, maxX: 5.3, minZ: -10.4, maxZ: -7 },
    ],
    start: { x: 0, z: 6.2, yaw: 0 },
    spots: [
      { id: "a", x: -3.6, z: -2.1, prop: "desk" },
      { id: "b", x: 0, z: -5.2, prop: "paper" },
      { id: "c", x: 3.6, z: -8.7, prop: "panel" },
      { id: "far", x: 0, z: -12.5, prop: "phone" },
      { id: "exit", x: 0, z: -14.15, prop: "door" },
      { id: "cover1", x: -3.7, z: -3.2, prop: "locker" },
      { id: "cover2", x: 3.6, z: -7.55, prop: "locker" },
      { id: "power", x: 0.95, z: 5.3, prop: "panel" },
    ],
    threatPath: [
      { x: 0, z: 4.6 },
      { x: 0, z: -4 },
      { x: 0, z: -11.4 },
      { x: 0, z: -4 },
    ],
  };
}

function wing(): Layout {
  return {
    id: "wing",
    walk: [
      { minX: -10, maxX: 10, minZ: -1.3, maxZ: 1.6 },
      { minX: -9.2, maxX: -6.6, minZ: -6.2, maxZ: -1.3 },
      { minX: -1.3, maxX: 1.3, minZ: -6.2, maxZ: -1.3 },
      { minX: 6.6, maxX: 9.2, minZ: -6.2, maxZ: -1.3 },
    ],
    start: { x: -8.2, z: 0.35, yaw: -Math.PI / 2 },
    spots: [
      { id: "a", x: -7.9, z: -4.5, prop: "desk" },
      { id: "b", x: 0, z: -4.5, prop: "paper" },
      { id: "c", x: 7.9, z: -4.5, prop: "panel" },
      { id: "far", x: 3.4, z: 0.2, prop: "phone" },
      { id: "exit", x: 8.7, z: 0.25, prop: "door" },
      { id: "cover1", x: -8.4, z: -5.45, prop: "locker" },
      { id: "cover2", x: 8.4, z: -5.45, prop: "locker" },
      { id: "power", x: -5.4, z: 0.35, prop: "panel" },
    ],
    threatPath: [
      { x: -7.5, z: 0.15 },
      { x: 0, z: 0.15 },
      { x: 7.6, z: 0.15 },
      { x: 0, z: 0.15 },
    ],
  };
}

function archive(): Layout {
  return {
    id: "archive",
    walk: [
      { minX: -6, maxX: 6, minZ: 4, maxZ: 6 },
      { minX: -6, maxX: -4.2, minZ: -6, maxZ: 6 },
      { minX: -1.2, maxX: 1.2, minZ: -6, maxZ: 6 },
      { minX: 4.2, maxX: 6, minZ: -6, maxZ: 6 },
      { minX: -6, maxX: 6, minZ: -6.5, maxZ: -4.6 },
    ],
    start: { x: 0, z: 5.05, yaw: 0 },
    spots: [
      { id: "a", x: -5.1, z: 0.2, prop: "paper" },
      { id: "b", x: 0, z: -1.2, prop: "desk" },
      { id: "c", x: 5.1, z: -1.6, prop: "panel" },
      { id: "far", x: 5.1, z: 3.2, prop: "phone" },
      { id: "exit", x: 0, z: -5.55, prop: "door" },
      { id: "cover1", x: -5.1, z: 3.4, prop: "locker" },
      { id: "cover2", x: 5.1, z: 2.2, prop: "locker" },
      { id: "power", x: -5.1, z: 5.1, prop: "panel" },
    ],
    threatPath: [
      { x: 0, z: 5 },
      { x: -5.1, z: 5 },
      { x: -5.1, z: -5.2 },
      { x: 0, z: -5.2 },
      { x: 5.1, z: -5.2 },
      { x: 5.1, z: 5 },
      { x: 0, z: 5 },
    ],
  };
}

function stairs(): Layout {
  return {
    id: "stairs",
    walk: [
      { minX: -2, maxX: 2, minZ: 2.5, maxZ: 7 },
      { minX: -1, maxX: 1, minZ: 0.5, maxZ: 2.5 },
      { minX: -3.5, maxX: 3.5, minZ: -2.2, maxZ: 0.5 },
      { minX: -1, maxX: 1, minZ: -4.2, maxZ: -2.2 },
      { minX: -2.2, maxX: 2.2, minZ: -8.2, maxZ: -4.2 },
    ],
    start: { x: 0, z: 5.8, yaw: 0 },
    spots: [
      { id: "a", x: -2.3, z: -0.7, prop: "panel" },
      { id: "b", x: 2.2, z: -1.15, prop: "paper" },
      { id: "c", x: 0, z: -6.2, prop: "desk" },
      { id: "far", x: 0, z: 3.5, prop: "phone" },
      { id: "exit", x: 0, z: -7.55, prop: "door" },
      { id: "cover1", x: -2.7, z: -1.55, prop: "locker" },
      { id: "cover2", x: 2.7, z: -1.55, prop: "locker" },
      { id: "power", x: 1.15, z: 5.4, prop: "panel" },
    ],
    threatPath: [
      { x: 0, z: 5.2 },
      { x: 0, z: -1 },
      { x: 0, z: -6.4 },
      { x: 0, z: -1 },
    ],
  };
}

function core(): Layout {
  return {
    id: "core",
    walk: [
      { minX: -7, maxX: 7, minZ: 4.2, maxZ: 7 },
      { minX: -7, maxX: 7, minZ: -7, maxZ: -4.2 },
      { minX: -7, maxX: -4.2, minZ: -7, maxZ: 7 },
      { minX: 4.2, maxX: 7, minZ: -7, maxZ: 7 },
    ],
    start: { x: 0, z: 5.6, yaw: 0 },
    spots: [
      { id: "a", x: 0, z: 4.85, prop: "pedestal" },
      { id: "b", x: -5.55, z: 0.1, prop: "paper" },
      { id: "c", x: 5.55, z: -1.1, prop: "panel" },
      { id: "far", x: 0, z: -5, prop: "phone" },
      { id: "exit", x: 0, z: -6.25, prop: "door" },
      { id: "cover1", x: -5.6, z: 5.2, prop: "locker" },
      { id: "cover2", x: 5.6, z: -5.3, prop: "locker" },
      { id: "power", x: -6.1, z: 5.55, prop: "panel" },
    ],
    threatPath: [
      { x: 0, z: 5.5 },
      { x: -5.6, z: 5.5 },
      { x: -5.6, z: -5.5 },
      { x: 5.6, z: -5.5 },
      { x: 5.6, z: 5.5 },
      { x: 0, z: 5.5 },
    ],
  };
}

function ward(): Layout {
  return {
    id: "ward",
    walk: [
      { minX: -1.6, maxX: 1.6, minZ: -8, maxZ: 7.5 },
      { minX: -5.2, maxX: -1.6, minZ: 2.2, maxZ: 4.6 },
      { minX: 1.6, maxX: 5.2, minZ: -1.6, maxZ: 0.8 },
      { minX: -5.2, maxX: -1.6, minZ: -5.8, maxZ: -3.4 },
      { minX: 1.6, maxX: 5.2, minZ: -8, maxZ: -5.6 },
    ],
    start: { x: 0, z: 6.3, yaw: 0 },
    spots: [
      { id: "a", x: -3.6, z: 3.4, prop: "desk" },
      { id: "b", x: 3.45, z: -0.35, prop: "paper" },
      { id: "c", x: -3.55, z: -4.55, prop: "panel" },
      { id: "far", x: 3.45, z: -6.75, prop: "phone" },
      { id: "exit", x: 0, z: -7.25, prop: "door" },
      { id: "cover1", x: -3.9, z: 2.7, prop: "locker" },
      { id: "cover2", x: 3.7, z: -6.7, prop: "locker" },
      { id: "power", x: 0, z: 4.6, prop: "panel" },
    ],
    threatPath: [
      { x: 0, z: 5.6 },
      { x: 0, z: 0 },
      { x: 0, z: -6.2 },
      { x: 0, z: 0 },
    ],
  };
}

const BUILDERS: Record<LayoutId, () => Layout> = {
  hall,
  wing,
  archive,
  stairs,
  core,
  ward,
};

export function getLayout(id: LayoutId): Layout {
  return BUILDERS[id]();
}

export function pointInside(layout: Layout, x: number, z: number, pad = 0): boolean {
  return layout.walk.some(
    (r) => x >= r.minX - pad && x <= r.maxX + pad && z >= r.minZ - pad && z <= r.maxZ + pad,
  );
}

export function assertLayouts(): void {
  (Object.keys(BUILDERS) as LayoutId[]).forEach((id) => {
    const layout = getLayout(id);
    const ids = new Set<string>();
    for (const spot of layout.spots) {
      if (ids.has(spot.id)) throw new Error(`duplicate spot ${id}:${spot.id}`);
      ids.add(spot.id);
      if (!pointInside(layout, spot.x, spot.z)) {
        throw new Error(`spot outside ${id}:${spot.id} ${spot.x},${spot.z}`);
      }
    }
    for (const p of layout.threatPath) {
      if (!pointInside(layout, p.x, p.z)) {
        throw new Error(`path outside ${id} ${p.x},${p.z}`);
      }
    }
    if (!pointInside(layout, layout.start.x, layout.start.z)) {
      throw new Error(`start outside ${id}`);
    }
  });
}

import type { Settings } from "./types";

export class AudioBus {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private ambientGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private sfxGain: GainNode | null = null;
  private noise: AudioBuffer | null = null;
  private wind: AudioBufferSourceNode | null = null;
  private hum: OscillatorNode | null = null;
  private droneNodes: OscillatorNode[] = [];
  private started = false;

  ensure(): AudioContext | null {
    if (typeof window === "undefined") return null;
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!Ctx) return null;
    if (!this.ctx) {
      const ctx = new Ctx();
      const master = ctx.createGain();
      master.gain.value = 0.9;
      master.connect(ctx.destination);
      const ambientGain = ctx.createGain();
      const musicGain = ctx.createGain();
      const sfxGain = ctx.createGain();
      ambientGain.connect(master);
      musicGain.connect(master);
      sfxGain.connect(master);
      const length = ctx.sampleRate * 2;
      const noise = ctx.createBuffer(1, length, ctx.sampleRate);
      const data = noise.getChannelData(0);
      let last = 0;
      for (let i = 0; i < length; i += 1) {
        const white = Math.random() * 2 - 1;
        last = last * 0.98 + white * 0.02;
        data[i] = last * 2.5;
      }
      this.ctx = ctx;
      this.master = master;
      this.ambientGain = ambientGain;
      this.musicGain = musicGain;
      this.sfxGain = sfxGain;
      this.noise = noise;
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  setMix(settings: Settings): void {
    if (!this.ctx || !this.ambientGain || !this.musicGain || !this.sfxGain) return;
    const now = this.ctx.currentTime;
    this.ambientGain.gain.setTargetAtTime(settings.ambient, now, 0.05);
    this.musicGain.gain.setTargetAtTime(settings.music, now, 0.05);
    this.sfxGain.gain.setTargetAtTime(settings.sfx, now, 0.05);
  }

  startBed(): void {
    const ctx = this.ensure();
    if (!ctx || !this.noise || !this.ambientGain || this.started) return;
    this.started = true;
    const source = ctx.createBufferSource();
    source.buffer = this.noise;
    source.loop = true;
    const filter = ctx.createBiquadFilter();
    filter.type = "lowpass";
    filter.frequency.value = 420;
    const gain = ctx.createGain();
    gain.gain.value = 0.18;
    source.connect(filter);
    filter.connect(gain);
    gain.connect(this.ambientGain);
    source.start();
    this.wind = source;

    const hum = ctx.createOscillator();
    hum.type = "sine";
    hum.frequency.value = 58;
    const humGain = ctx.createGain();
    humGain.gain.value = 0.03;
    hum.connect(humGain);
    humGain.connect(this.ambientGain);
    hum.start();
    this.hum = hum;
  }

  stopBed(): void {
    this.wind?.stop();
    this.hum?.stop();
    this.wind = null;
    this.hum = null;
    this.started = false;
    this.stopDrone();
  }

  duck(amount: number): void {
    if (!this.ctx || !this.ambientGain) return;
    this.ambientGain.gain.setTargetAtTime(amount, this.ctx.currentTime, 0.08);
  }

  foot(): void {
    this.blip(180, 0.045, "sine", 0.05);
    this.noiseBurst(0.05, 900, 0.04);
  }

  ui(): void {
    this.blip(520, 0.04, "triangle", 0.03);
  }

  door(): void {
    this.noiseBurst(0.35, 240, 0.08);
    this.blip(90, 0.2, "sine", 0.05);
  }

  ring(): void {
    this.blip(480, 0.18, "square", 0.03);
    window.setTimeout(() => this.blip(440, 0.18, "square", 0.03), 220);
  }

  stinger(): void {
    this.blip(72, 0.35, "sine", 0.06);
  }

  distantStep(): void {
    this.blip(140, 0.08, "sine", 0.02);
  }

  startDrone(): void {
    const ctx = this.ensure();
    if (!ctx || !this.musicGain || this.droneNodes.length) return;
    [98, 146].forEach((freq, index) => {
      const osc = ctx.createOscillator();
      osc.type = "sine";
      osc.frequency.value = freq;
      const gain = ctx.createGain();
      gain.gain.value = index === 0 ? 0.04 : 0.02;
      osc.connect(gain);
      gain.connect(this.musicGain as GainNode);
      osc.start();
      this.droneNodes.push(osc);
    });
  }

  stopDrone(): void {
    this.droneNodes.forEach((node) => {
      try {
        node.stop();
      } catch {
        /* already stopped */
      }
    });
    this.droneNodes = [];
  }

  private blip(freq: number, dur: number, type: OscillatorType, volume: number): void {
    const ctx = this.ensure();
    if (!ctx || !this.sfxGain) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    osc.connect(gain);
    gain.connect(this.sfxGain);
    osc.start();
    osc.stop(ctx.currentTime + dur + 0.02);
  }

  private noiseBurst(dur: number, freq: number, volume: number): void {
    const ctx = this.ensure();
    if (!ctx || !this.noise || !this.sfxGain) return;
    const source = ctx.createBufferSource();
    source.buffer = this.noise;
    const filter = ctx.createBiquadFilter();
    filter.type = "bandpass";
    filter.frequency.value = freq;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + dur);
    source.connect(filter);
    filter.connect(gain);
    gain.connect(this.sfxGain);
    source.start();
    source.stop(ctx.currentTime + dur + 0.02);
  }
}

export const audio = new AudioBus();

import { DEFAULT_SETTINGS, heroName, type SaveSlot, type Settings } from "./types";

const SLOT_KEY = "avida-floor-zero-slots-v1";
const ACTIVE_KEY = "avida-floor-zero-active-v1";
const SETTINGS_KEY = "avida-floor-zero-settings-v1";

type Store = Partial<Record<1 | 2 | 3, SaveSlot>>;

function readJson<T>(key: string): T | null {
  if (typeof localStorage === "undefined") return null;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return null;
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function writeJson(key: string, value: unknown): void {
  if (typeof localStorage === "undefined") return;
  localStorage.setItem(key, JSON.stringify(value));
}

export function loadSettings(): Settings {
  const saved = readJson<Settings>(SETTINGS_KEY);
  return { ...DEFAULT_SETTINGS, ...saved };
}

export function saveSettings(settings: Settings): void {
  writeJson(SETTINGS_KEY, settings);
}

export function loadSlots(): Store {
  return readJson<Store>(SLOT_KEY) ?? {};
}

export function loadSlot(slot: 1 | 2 | 3): SaveSlot | null {
  const found = loadSlots()[slot];
  if (!found || found.version !== 1) return null;
  return found;
}

export function writeSlot(slot: SaveSlot): void {
  const all = loadSlots();
  all[slot.slot] = slot;
  writeJson(SLOT_KEY, all);
  writeJson(ACTIVE_KEY, slot.slot);
  saveSettings(slot.settings);
}

export function activeSlotId(): 1 | 2 | 3 | null {
  const id = readJson<number>(ACTIVE_KEY);
  if (id === 1 || id === 2 || id === 3) return id;
  return null;
}

export function latestSlot(): SaveSlot | null {
  const all = loadSlots();
  const slots = [all[1], all[2], all[3]].filter((item): item is SaveSlot => !!item && item.version === 1);
  slots.sort((a, b) => b.updatedAt - a.updatedAt);
  return slots[0] ?? null;
}

export function createSlot(slotId: 1 | 2 | 3, character: SaveSlot["character"], settings: Settings): SaveSlot {
  const slot: SaveSlot = {
    version: 1,
    slot: slotId,
    updatedAt: Date.now(),
    character,
    name: heroName(character),
    unlocked: 1,
    current: 1,
    completed: [],
    clues: [],
    flags: {},
    progress: {},
    settings,
    tutorialDone: false,
  };
  writeSlot(slot);
  return slot;
}

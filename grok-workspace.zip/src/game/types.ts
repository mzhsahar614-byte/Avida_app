export type CharacterId = "girl" | "boy";
export type Quality = "low" | "med" | "high";
export type LayoutId = "hall" | "wing" | "archive" | "stairs" | "core" | "ward";
export type PaletteId = "cold" | "green" | "ink" | "dust" | "zero";
export type Category = "docs" | "people" | "places" | "messages" | "theories" | "confirmed";
export type FlagKey = "path" | "trust" | "files" | "door" | "phone";
export type Flags = Partial<Record<FlagKey, string>>;

export interface Settings {
  ambient: number;
  music: number;
  sfx: number;
  quality: Quality;
  sensitivity: number;
  vibrate: boolean;
}

export interface Clue {
  id: string;
  category: Category;
  title: string;
  body: string;
}

export interface Note {
  title: string;
  body: string;
}

export interface ChoiceOption {
  id: string;
  label: string;
  value: string;
  result: string;
}

export interface PickOption {
  id: string;
  label: string;
  detail?: string;
}

export type Puzzle =
  | { kind: "code"; prompt: string; hint: string; solution: string }
  | {
      kind: "switches";
      prompt: string;
      hint: string;
      solution: string;
      labels: string[];
      pattern: boolean[];
    }
  | {
      kind: "sequence";
      prompt: string;
      hint: string;
      solution: string;
      labels: string[];
      order: number[];
    }
  | {
      kind: "choice";
      prompt: string;
      hint: string;
      solution: string;
      flag: FlagKey;
      options: ChoiceOption[];
    }
  | {
      kind: "pick";
      prompt: string;
      hint: string;
      solution: string;
      text: string;
      options: PickOption[];
      answer: string;
    }
  | { kind: "visit"; prompt: string; hint: string; solution: string; spots: string[] }
  | { kind: "hide"; prompt: string; hint: string; solution: string; goal: string }
  | { kind: "carry"; prompt: string; hint: string; solution: string; itemSpot: string; itemName: string; targetSpot: string }
  | {
      kind: "phone";
      prompt: string;
      hint: string;
      solution: string;
      lines: string;
      linesIf?: { flag: FlagKey; equals: string; lines: string }[];
      flag?: FlagKey;
      options?: ChoiceOption[];
    };

export interface LevelDef {
  id: number;
  chapter: 1 | 2 | 3 | 4 | 5;
  title: string;
  place: string;
  objective: string;
  story: string;
  debrief: string;
  layout: LayoutId;
  palette: PaletteId;
  elevator?: boolean;
  threat?: { kind: "sound" | "light" | "presence" | "both"; name: string };
  clue: Clue;
  extraClues?: Clue[];
  puzzleSpot: string;
  puzzle: Puzzle;
  notes: Record<string, Note>;
}

export interface LevelProgress {
  solved: boolean;
  visited: string[];
  holding: boolean;
}

export interface SaveSlot {
  version: 1;
  slot: 1 | 2 | 3;
  updatedAt: number;
  character: CharacterId;
  name: string;
  unlocked: number;
  current: number;
  completed: number[];
  clues: Clue[];
  flags: Flags;
  progress: Record<string, LevelProgress>;
  settings: Settings;
  tutorialDone: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  ambient: 0.7,
  music: 0.35,
  sfx: 0.8,
  quality: "med",
  sensitivity: 1,
  vibrate: true,
};

export const CATEGORY_LABEL: Record<Category, string> = {
  docs: "مدارک",
  people: "اشخاص",
  places: "مکان‌ها",
  messages: "پیام‌ها",
  theories: "فرضیه‌ها",
  confirmed: "اطلاعات تأییدشده",
};

export const CHAPTERS: { id: 1 | 2 | 3 | 4 | 5; title: string; from: number; to: number }[] = [
  { id: 1, title: "بیداری", from: 1, to: 10 },
  { id: 2, title: "راهروهای فراموش‌شده", from: 11, to: 20 },
  { id: 3, title: "پرونده‌های ممنوعه", from: 21, to: 30 },
  { id: 4, title: "حقیقت زیر ساختمان", from: 31, to: 40 },
  { id: 5, title: "طبقه صفر", from: 41, to: 50 },
];

export function heroName(id: CharacterId): string {
  return id === "girl" ? "آوا" : "آراد";
}

export function chapterOf(levelId: number): 1 | 2 | 3 | 4 | 5 {
  if (levelId <= 10) return 1;
  if (levelId <= 20) return 2;
  if (levelId <= 30) return 3;
  if (levelId <= 40) return 4;
  return 5;
}

export function chapterTitle(levelId: number): string {
  return CHAPTERS[chapterOf(levelId) - 1]?.title ?? "";
}

import { useEffect, useState } from "react";
import { PlaySession } from "@/components/avida/PlaySession";
import { audio } from "@/game/audio";
import { faNum } from "@/game/fa";
import { endingFor } from "@/game/levels";
import { activeSlotId, createSlot, latestSlot, loadSettings, loadSlot, saveSettings, writeSlot } from "@/game/save";
import { CHAPTERS, CATEGORY_LABEL, DEFAULT_SETTINGS, type CharacterId, type Quality, type SaveSlot, type Settings } from "@/game/types";

type Screen = "title" | "character" | "slots" | "stages" | "settings" | "manual" | "credits" | "play" | "ending" | "farewell" | "journal";

export function AvidaApp() {
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState<Screen>("title");
  const [settings, setSettings] = useState<Settings>(DEFAULT_SETTINGS);
  const [slot, setSlot] = useState<SaveSlot | null>(null);
  const [levelId, setLevelId] = useState(1);
  const [pendingChar, setPendingChar] = useState<CharacterId>("girl");

  useEffect(() => {
    const stored = loadSettings();
    setSettings(stored);
    const active = activeSlotId();
    const found = (active && loadSlot(active)) || latestSlot();
    if (found) {
      setSlot(found);
      setLevelId(found.current || 1);
    }
    setReady(true);
    const boot = () => {
      audio.ensure();
      audio.startBed();
      audio.startDrone();
      audio.setMix(stored);
    };
    window.addEventListener("pointerdown", boot, { once: true });
    return () => window.removeEventListener("pointerdown", boot);
  }, []);

  useEffect(() => {
    if (!ready) return;
    saveSettings(settings);
    audio.setMix(settings);
  }, [ready, settings]);

  function updateSettings(patch: Partial<Settings>) {
    setSettings((curr) => ({ ...curr, ...patch }));
    setSlot((curr) => (curr ? { ...curr, settings: { ...curr.settings, ...patch } } : curr));
  }

  function begin(id: number, nextSlot = slot) {
    if (!nextSlot) return;
    const updated = { ...nextSlot, current: id, settings, updatedAt: Date.now() };
    writeSlot(updated);
    setSlot(updated);
    setLevelId(id);
    audio.stopDrone();
    setScreen("play");
  }

  const continueSlot = slot;

  return (
    <main className="app-shell">
      {screen === "title" ? (
        <section className="screen">
          <div className="brand-block">
            <p className="kicker">ساعت ۳:۱۷</p>
            <h1 className="logo-mark">AVIDA</h1>
            <p className="fa-title">طبقه صفر</p>
            <p className="sign">ایده و هویت هنری: AVIDA</p>
          </div>
          <div className="menu-list">
            <button type="button" className="btn btn-primary" onClick={() => { audio.ensure(); audio.startBed(); setScreen("character"); }}>
              شروع بازی
            </button>
            <button type="button" className="btn" disabled={!ready || !continueSlot} onClick={() => continueSlot && begin(continueSlot.current || 1)}>
              ادامه بازی
              {continueSlot ? <small>{continueSlot.name} · مرحله {faNum(continueSlot.current)}</small> : <small>پرونده‌ای ذخیره نشده</small>}
            </button>
            <button type="button" className="btn" disabled={!continueSlot} onClick={() => setScreen("stages")}>
              انتخاب مرحله
            </button>
            <button type="button" className="btn" onClick={() => setScreen("settings")}>تنظیمات</button>
            <button type="button" className="btn" onClick={() => setScreen("manual")}>دفترچه راهنما</button>
            <button type="button" className="btn" onClick={() => setScreen("credits")}>عوامل سازنده</button>
            <button type="button" className="btn btn-ghost" onClick={() => setScreen("farewell")}>خروج</button>
          </div>
        </section>
      ) : null}

      {screen === "character" ? (
        <section className="screen">
          <p className="kicker">انتخاب شخصیت</p>
          <h2>چه کسی در کابین بیدار می‌شود؟</h2>
          <p className="body-copy">داستان برای هر دو یکی است. نام روی کارت، بعدها با همین انتخاب خوانا می‌شود.</p>
          <div className="chars">
            <button type="button" className="btn char-card" onClick={() => { setPendingChar("girl"); setScreen("slots"); }}>
              <strong>آوا</strong>
              <small>شخصیت دختر</small>
            </button>
            <button type="button" className="btn char-card" onClick={() => { setPendingChar("boy"); setScreen("slots"); }}>
              <strong>آراد</strong>
              <small>شخصیت پسر</small>
            </button>
          </div>
          <button type="button" className="btn" onClick={() => setScreen("title")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "slots" ? (
        <section className="screen">
          <p className="kicker">سه جای ذخیره</p>
          <h2>پرونده را کجا بگذاریم؟</h2>
          <SlotList
            onPick={(id) => {
              const created = createSlot(id, pendingChar, settings);
              setSlot(created);
              begin(1, created);
            }}
          />
          <button type="button" className="btn" onClick={() => setScreen("character")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "stages" && slot ? (
        <section className="screen">
          <p className="kicker">مراحل بازشده</p>
          <h2>انتخاب مرحله</h2>
          {CHAPTERS.map((chapter) => (
            <div key={chapter.id} className="panel">
              <strong>فصل {faNum(chapter.id)} · {chapter.title}</strong>
              <div className="stage-grid">
                {Array.from({ length: chapter.to - chapter.from + 1 }, (_, index) => chapter.from + index).map((id) => {
                  const locked = id > slot.unlocked;
                  const done = slot.completed.includes(id);
                  return (
                    <button key={id} type="button" className={done ? "btn btn-on" : "btn"} disabled={locked} onClick={() => begin(id)}>
                      {faNum(id)}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          <button type="button" className="btn" onClick={() => setScreen("title")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "settings" ? (
        <section className="screen">
          <p className="kicker">AVIDA</p>
          <h2>تنظیمات</h2>
          <label className="panel">صدای محیط
            <input className="slider" type="range" min={0} max={1} step={0.05} value={settings.ambient} onChange={(event) => updateSettings({ ambient: Number(event.target.value) })} />
          </label>
          <label className="panel">موسیقی
            <input className="slider" type="range" min={0} max={1} step={0.05} value={settings.music} onChange={(event) => updateSettings({ music: Number(event.target.value) })} />
          </label>
          <label className="panel">افکت‌ها
            <input className="slider" type="range" min={0} max={1} step={0.05} value={settings.sfx} onChange={(event) => updateSettings({ sfx: Number(event.target.value) })} />
          </label>
          <div className="panel">
            <p>کیفیت گرافیک</p>
            <div className="stack">
              {(["low", "med", "high"] as Quality[]).map((quality) => (
                <button key={quality} type="button" className={settings.quality === quality ? "btn btn-on" : "btn"} onClick={() => updateSettings({ quality })}>
                  {quality === "low" ? "ضعیف: مه بیشتر، نور کمتر" : quality === "med" ? "متوسط" : "قوی: سایه و غبار نور"}
                </button>
              ))}
            </div>
            <p className="hint">اگر وسط مرحله عوضش کنی، با شروع دوباره همان مرحله اعمال می‌شود.</p>
          </div>
          <label className="panel">حساسیت نگاه
            <input className="slider" type="range" min={0.6} max={1.6} step={0.05} value={settings.sensitivity} onChange={(event) => updateSettings({ sensitivity: Number(event.target.value) })} />
          </label>
          <button type="button" className={settings.vibrate ? "btn btn-on" : "btn"} onClick={() => updateSettings({ vibrate: !settings.vibrate })}>
            لرزش گوشی: {settings.vibrate ? "روشن" : "خاموش"}
          </button>
          <div className="panel">
            <p>زبان</p>
            <p className="body-copy">فارسی، زبان اصلی و تنها زبان این نسخه است.</p>
          </div>
          <p className="sign">ایده و هویت هنری: AVIDA</p>
          <button type="button" className="btn" onClick={() => setScreen("title")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "manual" ? (
        <section className="screen">
          <h2>دفترچه راهنما</h2>
          <article className="panel"><strong>حرکت</strong><p className="body-copy">سمت راست صفحه اهرم حرکت است. کشیدن انگشت روی بقیه صفحه، نگاه را می‌چرخاند. روی رایانه کلیدهای W و S برای جلو و عقب، A چپ و D راست است.</p></article>
          <article className="panel"><strong>دکمه‌ها</strong><p className="body-copy">نور چراغ‌قوه را کم و زیاد می‌کند و باتری دارد. جعبه برق پرش می‌کند. خم شدن کنار کمد، پناه است. دویدن صدا می‌سازد.</p></article>
          <article className="panel"><strong>دفترچه سرنخ‌ها</strong><p className="body-copy">مدارک، اشخاص، مکان‌ها، پیام‌ها، فرضیه‌ها و اطلاعات تأییدشده بعد از تمام شدن هر مرحله ثبت می‌شوند.</p></article>
          <article className="panel"><strong>راهنما</strong><p className="body-copy">دکمه راهنما اول فقط اشاره می‌کند. بار دوم راه حل را روشن می‌گوید تا جایی گیر نکنی.</p></article>
          <article className="panel"><strong>ذخیره</strong><p className="body-copy">سه پرونده روی همین دستگاه می‌ماند. با بستن صفحه و برگشتن، ادامه بازی همان مرحله را باز می‌کند.</p></article>
          {slot ? <button type="button" className="btn" onClick={() => setScreen("journal")}>سرنخ‌های جمع‌شده</button> : null}
          <button type="button" className="btn" onClick={() => setScreen("title")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "journal" && slot ? (
        <section className="screen">
          <h2>دفترچه سرنخ‌ها</h2>
          {slot.clues.length === 0 ? <p className="hint">هنوز سرنخی ثبت نشده.</p> : null}
          {Object.entries(CATEGORY_LABEL).map(([id, label]) => {
            const list = slot.clues.filter((clue) => clue.category === id);
            if (!list.length) return null;
            return (
              <div key={id} className="panel">
                <strong>{label}</strong>
                {list.map((clue) => (
                  <p key={clue.id} className="body-copy"><b>{clue.title}.</b> {clue.body}</p>
                ))}
              </div>
            );
          })}
          <button type="button" className="btn" onClick={() => setScreen("manual")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "credits" ? (
        <section className="screen">
          <p className="kicker">عوامل سازنده</p>
          <h2>آویدا: طبقه صفر</h2>
          <p className="body-copy">ایده و هویت هنری: AVIDA</p>
          <p className="body-copy">فضا، نور، روایت، معماها و صدای این نسخه برای همین بازی ساخته شده‌اند. صداها سنتز شده‌اند و از فایل آمادهٔ دیگران استفاده نشده.</p>
          <p className="body-copy">گرافیک با هندسه، بافت ساخته‌شده و نور لحظه‌ای است؛ مدل آماده‌ای از جای دیگر در صحنه نیست.</p>
          <p className="sign">AVIDA</p>
          <button type="button" className="btn" onClick={() => setScreen("title")}>بازگشت</button>
        </section>
      ) : null}

      {screen === "farewell" ? (
        <section className="screen">
          <h2>خروج</h2>
          <p className="body-copy">ساختمان خاموش می‌ماند. اگر این صفحه را ببندی، پرونده‌ات روی دستگاه می‌ماند.</p>
          <p className="sign">AVIDA</p>
          <button type="button" className="btn btn-primary" onClick={() => setScreen("title")}>بازگشت به بازی</button>
        </section>
      ) : null}

      {screen === "ending" && slot ? (
        <Ending slot={slot} onMenu={() => setScreen("title")} onReplay={() => {
          const fresh = createSlot(slot.slot, slot.character, settings);
          setSlot(fresh);
          begin(1, fresh);
        }} />
      ) : null}

      {screen === "play" && slot ? (
        <PlaySession
          key={`${slot.slot}-${levelId}`}
          slot={slot}
          levelId={levelId}
          onSlot={(next) => {
            writeSlot(next);
            setSlot(next);
          }}
          onMenu={() => {
            audio.startDrone();
            setScreen("title");
          }}
          onEnding={() => setScreen("ending")}
          onNext={() => begin(Math.min(50, levelId + 1))}
        />
      ) : null}
    </main>
  );
}

function SlotList({ onPick }: { onPick: (id: 1 | 2 | 3) => void }) {
  const [slots, setSlots] = useState<(SaveSlot | null)[]>([null, null, null]);
  const [ask, setAsk] = useState<1 | 2 | 3 | null>(null);
  useEffect(() => {
    setSlots([loadSlot(1), loadSlot(2), loadSlot(3)]);
  }, []);
  const asked = ask ? slots[ask - 1] : null;
  return (
    <div className="stack">
      {ask && asked ? (
        <div className="panel">
          <p className="body-copy">پرونده {faNum(ask)} مال {asked.name} است. جایگزین شود؟</p>
          <button type="button" className="btn btn-primary" onClick={() => onPick(ask)}>
            بله، از نو شروع شود
          </button>
          <button type="button" className="btn" onClick={() => setAsk(null)}>
            نه
          </button>
        </div>
      ) : null}
      {([1, 2, 3] as const).map((id) => {
        const found = slots[id - 1];
        return (
          <button
            key={id}
            type="button"
            className="btn"
            onClick={() => {
              if (found) setAsk(id);
              else onPick(id);
            }}
          >
            پرونده {faNum(id)}
            {found ? <small>{found.name} · مرحله {faNum(found.current)} · {faNum(found.completed.length)} مرحله تمام‌شده</small> : <small>جای خالی</small>}
          </button>
        );
      })}
    </div>
  );
}

function Ending({ slot, onMenu, onReplay }: { slot: SaveSlot; onMenu: () => void; onReplay: () => void }) {
  const ending = endingFor(slot.flags, slot.name);
  useEffect(() => {
    audio.startDrone();
  }, []);
  return (
    <section className="screen">
      <p className="kicker">پایان</p>
      <h2>{ending.title}</h2>
      {ending.paragraphs.map((paragraph) => (
        <p key={paragraph} className="body-copy">{paragraph}</p>
      ))}
      <button type="button" className="btn btn-primary" onClick={onMenu}>منوی اصلی</button>
      <button type="button" className="btn" onClick={onReplay}>دوباره از آسانسور</button>
    </section>
  );
}

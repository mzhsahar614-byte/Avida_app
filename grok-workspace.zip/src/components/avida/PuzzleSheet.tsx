import { useEffect, useState } from "react";
import { faNum, fillName, toAsciiDigits } from "@/game/fa";
import { phoneScript } from "@/game/levels";
import type { Flags, LevelDef, Puzzle } from "@/game/types";

export function PuzzleSheet({
  level,
  flags,
  name,
  hintTier,
  onClose,
  onSolved,
  onFlag,
}: {
  level: LevelDef;
  flags: Flags;
  name: string;
  hintTier: number;
  onClose: () => void;
  onSolved: () => void;
  onFlag: (flag: "path" | "trust" | "files" | "door" | "phone", value: string) => void;
}) {
  const puzzle = level.puzzle;
  return (
    <section className="sheet" role="dialog" aria-modal="true" aria-labelledby="puzzle-title">
      <div className="sheet-card">
        <p className="kicker">{level.place}</p>
        <h2 id="puzzle-title">{fillName(puzzle.prompt, name)}</h2>
        <PuzzleBody
          puzzle={puzzle}
          level={level}
          flags={flags}
          name={name}
          hintTier={hintTier}
          onSolved={onSolved}
          onFlag={onFlag}
        />
        {hintTier > 0 ? <p className="hint">{hintTier >= 2 ? `راهنمای روشن: ${fillName(puzzle.solution, name)}` : fillName(puzzle.hint, name)}</p> : null}
        <button type="button" className="btn" onClick={onClose}>
          بستن
        </button>
      </div>
    </section>
  );
}

function PuzzleBody({
  puzzle,
  level,
  flags,
  name,
  hintTier,
  onSolved,
  onFlag,
}: {
  puzzle: Puzzle;
  level: LevelDef;
  flags: Flags;
  name: string;
  hintTier: number;
  onSolved: () => void;
  onFlag: (flag: "path" | "trust" | "files" | "door" | "phone", value: string) => void;
}) {
  if (puzzle.kind === "code") return <CodePuzzle puzzle={puzzle} hintTier={hintTier} onSolved={onSolved} />;
  if (puzzle.kind === "switches") return <SwitchPuzzle puzzle={puzzle} hintTier={hintTier} onSolved={onSolved} />;
  if (puzzle.kind === "sequence") return <SequencePuzzle puzzle={puzzle} hintTier={hintTier} onSolved={onSolved} />;
  if (puzzle.kind === "pick") return <PickPuzzle puzzle={puzzle} name={name} hintTier={hintTier} onSolved={onSolved} />;
  if (puzzle.kind === "choice") return <ChoicePuzzle options={puzzle.options} flag={puzzle.flag} onFlag={onFlag} onSolved={onSolved} />;
  if (puzzle.kind === "phone") {
    return (
      <PhonePuzzle
        lines={fillName(phoneScript(level, flags), name)}
        options={puzzle.options}
        flag={puzzle.flag}
        onFlag={onFlag}
        onSolved={onSolved}
      />
    );
  }
  return <p className="body-copy">این مرحله داخل راهرو حل می‌شود، نه روی این برگ.</p>;
}

function CodePuzzle({
  puzzle,
  hintTier,
  onSolved,
}: {
  puzzle: Extract<Puzzle, { kind: "code" }>;
  hintTier: number;
  onSolved: () => void;
}) {
  const target = toAsciiDigits(puzzle.solution);
  const [entry, setEntry] = useState("");
  const [wrong, setWrong] = useState(false);
  useEffect(() => {
    if (hintTier >= 2) setEntry(target);
  }, [hintTier, target]);
  return (
    <div>
      <p className={`code-read ${wrong ? "shake" : ""}`} dir="ltr">
        {entry ? faNum(entry) : "—"}
      </p>
      <div className="numpad" dir="ltr">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "تأیید"].map((key) => (
          <button
            key={key}
            type="button"
            className="btn num-key"
            onClick={() => {
              if (key === "⌫") {
                setEntry((value) => value.slice(0, -1));
                setWrong(false);
                return;
              }
              if (key === "تأیید") {
                if (entry === target) onSolved();
                else setWrong(true);
                return;
              }
              setWrong(false);
              setEntry((value) => (value.length >= target.length ? value : value + key));
            }}
          >
            {key === "⌫" || key === "تأیید" ? key : faNum(key)}
          </button>
        ))}
      </div>
      {wrong ? <p className="warn-text">این رمز نیست.</p> : null}
    </div>
  );
}

function SwitchPuzzle({
  puzzle,
  hintTier,
  onSolved,
}: {
  puzzle: Extract<Puzzle, { kind: "switches" }>;
  hintTier: number;
  onSolved: () => void;
}) {
  const [on, setOn] = useState<boolean[]>(() => puzzle.pattern.map(() => false));
  const [wrong, setWrong] = useState(false);
  useEffect(() => {
    if (hintTier >= 2) setOn(puzzle.pattern);
  }, [hintTier, puzzle]);
  return (
    <div>
      <div className="stack">
        {puzzle.labels.map((label, index) => (
          <button
            key={label}
            type="button"
            className={on[index] ? "btn btn-on" : "btn"}
            onClick={() => {
              setWrong(false);
              setOn((curr) => curr.map((value, i) => (i === index ? !value : value)));
            }}
          >
            {label}
            <small>{on[index] ? "روشن" : "خاموش"}</small>
          </button>
        ))}
      </div>
      <button
        type="button"
        className="btn btn-primary"
        onClick={() => {
          if (on.every((value, index) => value === puzzle.pattern[index])) onSolved();
          else setWrong(true);
        }}
      >
        تأیید ترکیب
      </button>
      {wrong ? <p className="warn-text">این ترکیب نیست.</p> : null}
    </div>
  );
}

function SequencePuzzle({
  puzzle,
  hintTier,
  onSolved,
}: {
  puzzle: Extract<Puzzle, { kind: "sequence" }>;
  hintTier: number;
  onSolved: () => void;
}) {
  const [got, setGot] = useState<number[]>([]);
  const [flash, setFlash] = useState<number | null>(null);
  const [wrong, setWrong] = useState(false);
  function playOrder() {
    puzzle.order.forEach((step, index) => {
      window.setTimeout(() => setFlash(step), index * 420);
    });
    window.setTimeout(() => setFlash(null), puzzle.order.length * 420 + 200);
  }
  useEffect(() => {
    playOrder();
    // only on open
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  return (
    <div>
      <p className="body-copy">الگو را به ترتیب بزن. {hintTier >= 2 ? faNum(puzzle.solution) : ""}</p>
      <div className="stack">
        {puzzle.labels.map((label, index) => (
          <button
            key={label}
            type="button"
            className={flash === index ? "btn btn-on" : "btn"}
            onClick={() => {
              const next = [...got, index];
              const good = puzzle.order.slice(0, next.length).every((step, i) => step === next[i]);
              if (!good) {
                setWrong(true);
                setGot([]);
                return;
              }
              setWrong(false);
              if (next.length === puzzle.order.length) onSolved();
              else setGot(next);
            }}
          >
            {label}
          </button>
        ))}
      </div>
      <p className="body-copy">گام‌های درست: {faNum(got.length)} از {faNum(puzzle.order.length)}</p>
      <button type="button" className="btn" onClick={playOrder}>
        نمایش دوباره الگو
      </button>
      {wrong ? <p className="warn-text">ترتیب به‌هم خورد. از اول.</p> : null}
    </div>
  );
}

function PickPuzzle({
  puzzle,
  name,
  hintTier,
  onSolved,
}: {
  puzzle: Extract<Puzzle, { kind: "pick" }>;
  name: string;
  hintTier: number;
  onSolved: () => void;
}) {
  const [wrong, setWrong] = useState(false);
  return (
    <div>
      <p className="doc">{fillName(puzzle.text, name)}</p>
      <div className="stack">
        {puzzle.options.map((option) => (
          <button
            key={option.id}
            type="button"
            className={hintTier >= 2 && option.id === puzzle.answer ? "btn btn-on" : "btn"}
            onClick={() => {
              if (option.id === puzzle.answer) onSolved();
              else setWrong(true);
            }}
          >
            <span>{fillName(option.label, name)}</span>
            {option.detail ? <small>{option.detail}</small> : null}
          </button>
        ))}
      </div>
      {wrong ? <p className="warn-text">این یکی با مدرک نمی‌خواند.</p> : null}
    </div>
  );
}

function ChoicePuzzle({
  options,
  flag,
  onFlag,
  onSolved,
}: {
  options: { id: string; label: string; value: string; result: string }[];
  flag: "path" | "trust" | "files" | "door" | "phone";
  onFlag: (flag: "path" | "trust" | "files" | "door" | "phone", value: string) => void;
  onSolved: () => void;
}) {
  const [result, setResult] = useState<string | null>(null);
  if (result) {
    return (
      <div>
        <p className="doc">{result}</p>
        <button type="button" className="btn btn-primary" onClick={onSolved}>
          ثبت انتخاب
        </button>
      </div>
    );
  }
  return (
    <div className="stack">
      {options.map((option) => (
        <button
          key={option.id}
          type="button"
          className="btn"
          onClick={() => {
            onFlag(flag, option.value);
            setResult(option.result);
          }}
        >
          {option.label}
        </button>
      ))}
    </div>
  );
}

function PhonePuzzle({
  lines,
  options,
  flag,
  onFlag,
  onSolved,
}: {
  lines: string;
  options?: { id: string; label: string; value: string; result: string }[];
  flag?: "path" | "trust" | "files" | "door" | "phone";
  onFlag: (flag: "path" | "trust" | "files" | "door" | "phone", value: string) => void;
  onSolved: () => void;
}) {
  const [result, setResult] = useState<string | null>(null);
  return (
    <div>
      <p className="doc phone-line">{lines}</p>
      {result ? <p className="body-copy">{result}</p> : null}
      {options && flag && !result ? (
        <div className="stack">
          {options.map((option) => (
            <button
              key={option.id}
              type="button"
              className="btn"
              onClick={() => {
                onFlag(flag, option.value);
                setResult(option.result);
              }}
            >
              {option.label}
            </button>
          ))}
        </div>
      ) : (
        <button type="button" className="btn btn-primary" onClick={onSolved}>
          {options ? "ثبت و قطع تماس" : "شنیدم"}
        </button>
      )}
    </div>
  );
}

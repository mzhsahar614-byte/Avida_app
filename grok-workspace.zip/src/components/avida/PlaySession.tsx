import { BookOpen, Flashlight, Footprints, Pause, PersonStanding } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { audio } from "@/game/audio";
import { faNum, fillName } from "@/game/fa";
import { getLayout, type Layout } from "@/game/layouts";
import { getLevel } from "@/game/levels";
import type { Flags, LevelDef, SaveSlot } from "@/game/types";
import { CATEGORY_LABEL, chapterTitle } from "@/game/types";
import { GameWorld, type FrameInfo } from "@/game/world";
import { PuzzleSheet } from "./PuzzleSheet";

type Phase = "intro" | "play" | "puzzle" | "note" | "pause" | "journal" | "guide" | "done";

export function PlaySession({
  slot,
  levelId,
  onSlot,
  onMenu,
  onEnding,
  onNext,
}: {
  slot: SaveSlot;
  levelId: number;
  onSlot: (slot: SaveSlot) => void;
  onMenu: () => void;
  onEnding: () => void;
  onNext: () => void;
}) {
  const level = getLevel(levelId);
  const layout = getLayout(level.layout);
  const saved = slot.progress[String(levelId)];
  const [phase, setPhase] = useState<Phase>("intro");
  const [solved, setSolved] = useState(saved?.solved ?? false);
  const [visited, setVisited] = useState<string[]>(saved?.visited ?? []);
  const [holding, setHolding] = useState(saved?.holding ?? false);
  const [hud, setHud] = useState<FrameInfo | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [note, setNote] = useState<{ title: string; body: string } | null>(null);
  const [hintTier, setHintTier] = useState(0);
  const [crouch, setCrouch] = useState(false);
  const [sprint, setSprint] = useState(false);
  const [flash, setFlash] = useState(false);
  const [runId, setRunId] = useState(0);
  const inputRef = useRef({ moveX: 0, moveY: 0, sprint: false, crouch: false, flashlight: false });
  const worldRef = useRef<GameWorld | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const slotRef = useRef(slot);
  const caughtRef = useRef(0);
  const phaseRef = useRef(phase);
  const hudRef = useRef<FrameInfo | null>(null);
  const solvedRef = useRef(solved);
  const visitedRef = useRef(visited);
  const holdingRef = useRef(holding);
  slotRef.current = slot;
  phaseRef.current = phase;
  solvedRef.current = solved;
  visitedRef.current = visited;
  holdingRef.current = holding;
  inputRef.current.sprint = sprint;
  inputRef.current.crouch = crouch;
  inputRef.current.flashlight = flash;

  function persist(patch: Partial<SaveSlot>) {
    const next = { ...slotRef.current, ...patch, settings: slotRef.current.settings, updatedAt: Date.now() };
    slotRef.current = next;
    onSlot(next);
  }

  function remember(nextVisited = visited, nextHolding = holding, nextSolved = solved) {
    persist({
      current: levelId,
      progress: {
        ...slotRef.current.progress,
        [String(levelId)]: { solved: nextSolved, visited: nextVisited, holding: nextHolding },
      },
    });
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const world = new GameWorld(
      canvas,
      level,
      layout,
      slot.settings.quality,
      () => inputRef.current,
      (frame) => {
        hudRef.current = frame;
        setHud(frame);
        if (frame.caught !== caughtRef.current) {
          caughtRef.current = frame.caught;
          setToast("شیفت تو را به آغاز مسیر برگرداند.");
          audio.stinger();
          if (slotRef.current.settings.vibrate) navigator.vibrate?.(50);
        }
      },
      () => audio.foot(),
      () => audio.distantStep(),
      slot.character === "girl" ? 0x6e8f8a : 0x6a7380,
    );
    world.setExitOpen(saved?.solved ?? false);
    world.setPaused(true);
    worldRef.current = world;
    return () => {
      world.destroy();
      worldRef.current = null;
    };
    // rebuild only when the stage or graphics pass changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [levelId, runId, slot.settings.quality]);

  useEffect(() => {
    worldRef.current?.setPaused(phase !== "play");
    worldRef.current?.setExitOpen(solved);
  }, [phase, solved]);

  useEffect(() => {
    if (phase !== "play" || level.puzzle.kind !== "phone" || solved) return;
    audio.ring();
    const id = window.setInterval(() => audio.ring(), 8000);
    return () => window.clearInterval(id);
  }, [phase, level, solved]);

  useEffect(() => {
    const down = (event: KeyboardEvent) => {
      if (event.repeat) return;
      if (["Space", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.code)) event.preventDefault();
      if (phaseRef.current !== "play") {
        if (event.code === "Escape") setPhase("play");
        return;
      }
      if (event.code === "KeyE" || event.code === "Space") pressInteract();
      if (event.code === "KeyC") setCrouch((value) => !value);
      if (event.code === "KeyF") setFlash((value) => !value);
      if (event.code === "ShiftLeft" || event.code === "ShiftRight") setSprint(true);
      if (event.code === "KeyJ") setPhase("journal");
      if (event.code === "Escape") setPhase("pause");
    };
    const up = (event: KeyboardEvent) => {
      if (event.code === "ShiftLeft" || event.code === "ShiftRight") setSprint(false);
    };
    window.addEventListener("keydown", down);
    window.addEventListener("keyup", up);
    return () => {
      window.removeEventListener("keydown", down);
      window.removeEventListener("keyup", up);
    };
  }, [level]);

  function pressInteract() {
    const id = hudRef.current?.nearId;
    const visitedNow = visitedRef.current;
    const holdingNow = holdingRef.current;
    const solvedNow = solvedRef.current;
    if (!id || phaseRef.current !== "play") return;
    audio.ui();
    if (id === "power") {
      worldRef.current?.recharge();
      setToast("جعبه برق جان گرفت. چراغ‌قوه پر شد.");
      audio.door();
      return;
    }
    if (id === "exit") {
      if (!solvedNow) {
        setToast("هنوز کار این مرحله تمام نشده.");
        return;
      }
      finish();
      return;
    }
    const puzzle = level.puzzle;
    if (puzzle.kind === "visit" && puzzle.spots.includes(id)) {
      const next = visitedNow.includes(id) ? visitedNow : [...visitedNow, id];
      setVisited(next);
      const done = puzzle.spots.every((spot) => next.includes(spot));
      if (done) setSolved(true);
      remember(next, holdingNow, done);
      openNote(id);
      return;
    }
    if (puzzle.kind === "carry") {
      if (id === puzzle.itemSpot && !holdingNow) {
        setHolding(true);
        remember(visitedNow, true, solvedNow);
        setToast(`${puzzle.itemName} را برداشتی.`);
        return;
      }
      if (id === puzzle.targetSpot) {
        if (!holdingNow) {
          setToast(`اول باید ${puzzle.itemName} را پیدا کنی.`);
          return;
        }
        setSolved(true);
        remember(visitedNow, true, true);
        setToast("درست جا گرفت.");
        audio.door();
        return;
      }
    }
    if (puzzle.kind === "hide" && id === puzzle.goal) {
      if ((hudRef.current?.detection ?? 0) > 0.72) {
        setToast("شیفت خیلی نزدیک است. پنهان شو.");
        return;
      }
      setSolved(true);
      remember(visitedNow, holdingNow, true);
      openNote(id);
      return;
    }
    if (id === level.puzzleSpot && puzzle.kind !== "visit" && puzzle.kind !== "carry" && puzzle.kind !== "hide") {
      if (solvedNow) {
        openNote(id);
        return;
      }
      setPhase("puzzle");
      audio.duck(0.25);
      return;
    }
    if (level.notes[id] || id.startsWith("cover")) {
      openNote(id);
      return;
    }
    setToast("چیز تازه‌ای این‌جا نیست.");
  }

  function openNote(id: string) {
    const base = level.notes[id];
    const title = base?.title ?? (id.startsWith("cover") ? "کمد" : "یادداشت");
    let body = fillName(base?.body ?? "جا برای پنهان شدن هست، اگر خم شوی.", slot.name);
    body = `${body} ${flagLine(level.id, id, slotRef.current.flags)}`.trim();
    setNote({ title, body });
    setPhase("note");
  }

  function markSolved() {
    setSolved(true);
    remember(visited, holding, true);
    setPhase("play");
    audio.duck(slot.settings.ambient);
    audio.door();
    setToast("این بخش انجام شد. به خروجی برو.");
  }

  function finish() {
    const clues = [...slotRef.current.clues];
    for (const clue of [level.clue, ...(level.extraClues ?? [])]) {
      if (!clues.some((item) => item.id === clue.id)) {
        clues.push({
          ...clue,
          title: fillName(clue.title, slot.name),
          body: fillName(clue.body, slot.name),
        });
      }
    }
    const completed = slotRef.current.completed.includes(level.id)
      ? slotRef.current.completed
      : [...slotRef.current.completed, level.id];
    const progress = { ...slotRef.current.progress };
    delete progress[String(level.id)];
    persist({
      clues,
      completed,
      unlocked: Math.max(slotRef.current.unlocked, Math.min(50, level.id + 1)),
      current: level.id < 50 ? level.id + 1 : 50,
      progress,
      tutorialDone: true,
    });
    audio.door();
    setPhase("done");
  }

  const goal = goalSpot(level, solved, visited, holding);
  const bearing = hud ? bearingTo(layout, hud, goal) : 0;
  const nearLabel = hud?.nearId ? spotTitle(level, hud.nearId) : "";

  return (
    <div className="play-root">
      <canvas
        ref={canvasRef}
        onPointerDown={(event) => {
          const shell = event.currentTarget.parentElement?.getBoundingClientRect();
          if (!shell) return;
          const localX = event.clientX - shell.left;
          if (event.pointerType !== "mouse" && localX < shell.width * 0.42) return;
          const pointer = { x: event.clientX, y: event.clientY };
          const moveLive = (ev: PointerEvent) => {
            worldRef.current?.addLook(ev.clientX - pointer.x, ev.clientY - pointer.y, slot.settings.sensitivity);
            pointer.x = ev.clientX;
            pointer.y = ev.clientY;
          };
          const up = () => {
            window.removeEventListener("pointermove", moveLive);
            window.removeEventListener("pointerup", up);
          };
          window.addEventListener("pointermove", moveLive);
          window.addEventListener("pointerup", up);
        }}
      />
      <div className="hud-top">
        <div className="hud-side" data-ui>
          <button type="button" className="icon-btn" onClick={() => setPhase("pause")} aria-label="توقف">
            <Pause size={18} />
          </button>
          <button type="button" className="icon-btn" onClick={() => setPhase("journal")} aria-label="دفترچه سرنخ‌ها">
            <BookOpen size={18} />
          </button>
        </div>
        <div className="objective">
          <strong>
            {chapterTitle(level.id)} · {faNum(level.id)} / {faNum(50)}
          </strong>
          <p>{level.objective}</p>
        </div>
        <div className="compass" style={{ transform: `rotate(${bearing}rad)` }} aria-hidden>
          <Footprints size={16} />
        </div>
      </div>
      {level.threat ? (
        <div className={hud && hud.detection > 0.72 ? "meter hot" : "meter"}>
          <span>هشیاری {level.threat.name}</span>
          <div className="bar">
            <i style={{ width: `${Math.round((hud?.detection ?? 0) * 100)}%` }} />
          </div>
        </div>
      ) : null}
      <div className="battery" style={{ position: "absolute", top: "5.5rem", left: "0.8rem" }}>
        چراغ‌قوه {faNum(Math.round(hud?.battery ?? 100))}٪
        <div className="bar">
          <i style={{ width: `${Math.round(hud?.battery ?? 100)}%` }} />
        </div>
        {holding ? <div>در دست: {level.puzzle.kind === "carry" ? level.puzzle.itemName : ""}</div> : null}
        {level.puzzle.kind === "visit" ? (
          <div>
            بررسی‌شده {faNum(visited.filter((id) => level.puzzle.kind === "visit" && level.puzzle.spots.includes(id)).length)} از{" "}
            {faNum(level.puzzle.spots.length)}
          </div>
        ) : null}
      </div>
      {hud?.nearId && phase === "play" ? (
        <button type="button" className="btn btn-primary prompt" data-ui onClick={pressInteract}>
          بررسی: {nearLabel}
        </button>
      ) : null}
      {toast && phase === "play" ? <div className="toast">{toast}</div> : null}
      <Stick
        onChange={(x, y) => {
          inputRef.current.moveX = x;
          inputRef.current.moveY = y;
        }}
      />
      <div className="actions" data-ui>
        <button type="button" className={sprint ? "icon-btn on" : "icon-btn"} onClick={() => setSprint((value) => !value)}>
          دویدن
        </button>
        <button type="button" className={crouch ? "icon-btn on" : "icon-btn"} onClick={() => setCrouch((value) => !value)}>
          <PersonStanding size={16} />
          خم
        </button>
        <button type="button" className={flash ? "icon-btn on" : "icon-btn"} onClick={() => setFlash((value) => !value)}>
          <Flashlight size={16} />
          نور
        </button>
        <button type="button" className="icon-btn" onClick={() => setPhase("guide")}>
          راهنما
        </button>
      </div>

      {phase === "intro" ? (
        <div className="overlay">
          <div className="modal-card">
            <p className="kicker">
              فصل {faNum(level.chapter)} · {chapterTitle(level.id)}
            </p>
            <h2>
              {faNum(level.id)}. {level.title}
            </h2>
            <p className="body-copy">{fillName(level.story, slot.name)}</p>
            <p className="body-copy">هدف: {level.objective}</p>
            {level.id === 1 && !slot.tutorialDone ? (
              <p className="hint">سمت راست حرکت، کشیدن انگشت برای نگاه، و دکمه‌های چپ برای نور، خم شدن و دویدن است. روی رایانه: W و S و A و D، با Shift برای دویدن.</p>
            ) : null}
            <button
              type="button"
              className="btn btn-primary"
              onClick={() => {
                audio.startBed();
                audio.setMix(slot.settings);
                audio.stopDrone();
                setPhase("play");
              }}
            >
              ورود
            </button>
          </div>
        </div>
      ) : null}

      {phase === "puzzle" ? (
        <PuzzleSheet
          level={level}
          flags={slot.flags}
          name={slot.name}
          hintTier={hintTier}
          onClose={() => {
            audio.duck(slot.settings.ambient);
            setPhase("play");
          }}
          onSolved={markSolved}
          onFlag={(flag, value) => persist({ flags: { ...slotRef.current.flags, [flag]: value } })}
        />
      ) : null}

      {phase === "note" && note ? (
        <div className="overlay">
          <div className="modal-card">
            <h2>{note.title}</h2>
            <p className="doc">{note.body}</p>
            <button type="button" className="btn btn-primary" onClick={() => setPhase("play")}>
              بستن
            </button>
          </div>
        </div>
      ) : null}

      {phase === "guide" ? (
        <div className="overlay">
          <div className="modal-card">
            <h2>راهنما</h2>
            <p className="body-copy">{hintTier === 0 ? "راهنما جواب را یک‌جا نمی‌گوید." : hintTier === 1 ? level.puzzle.hint : `راه حل: ${level.puzzle.solution}`}</p>
            <button type="button" className="btn" onClick={() => setHintTier((value) => Math.min(2, value + 1))}>
              {hintTier >= 2 ? "همین کافی است" : "راهنمای بیشتر"}
            </button>
            <button type="button" className="btn btn-primary" onClick={() => setPhase("play")}>
              برگشت به بازی
            </button>
          </div>
        </div>
      ) : null}

      {phase === "pause" ? (
        <div className="overlay">
          <div className="modal-card">
            <p className="kicker">AVIDA</p>
            <h2>توقف</h2>
            <button type="button" className="btn btn-primary" onClick={() => setPhase("play")}>
              ادامه
            </button>
            <button type="button" className="btn" onClick={() => setPhase("journal")}>
              دفترچه سرنخ‌ها
            </button>
            <button
              type="button"
              className="btn"
              onClick={() => {
                setSolved(false);
                setVisited([]);
                setHolding(false);
                setHintTier(0);
                persist({ progress: { ...slotRef.current.progress, [String(levelId)]: { solved: false, visited: [], holding: false } } });
                setRunId((value) => value + 1);
                setPhase("intro");
              }}
            >
              شروع دوباره این مرحله
            </button>
            <button type="button" className="btn" onClick={onMenu}>
              بازگشت به منو
            </button>
          </div>
        </div>
      ) : null}

      {phase === "journal" ? (
        <Journal clues={slot.clues} onClose={() => setPhase("play")} />
      ) : null}

      {phase === "done" ? (
        <div className="overlay">
          <div className="modal-card">
            <p className="kicker">مرحله تمام شد</p>
            <h2>{level.title}</h2>
            <p className="body-copy">{fillName(level.debrief, slot.name)}</p>
            <p className="hint">سرنخ تازه‌ای در دفترچه ثبت شد: {fillName(level.clue.title, slot.name)}</p>
            {level.id < 50 ? (
              <button type="button" className="btn btn-primary" onClick={onNext}>
                مرحله بعد
              </button>
            ) : (
              <button type="button" className="btn btn-primary" onClick={onEnding}>
                دیدن پایان
              </button>
            )}
            <button type="button" className="btn" onClick={onMenu}>
              منوی اصلی
            </button>
          </div>
        </div>
      ) : null}
    </div>
  );
}

function flagLine(levelId: number, spotId: string, flags: Flags): string {
  if (levelId !== 50) return "";
  if (spotId === "a") {
    if (flags.door === "shut") return "تصمیم تو: در را باز نکردی.";
    if (flags.door === "open") return "تصمیم تو: در را باز کردی.";
    return "تصمیم در هنوز ثبت نشده.";
  }
  if (spotId === "b") {
    if (flags.files === "seal") return "تصمیم تو: آرشیو مُهر شده.";
    if (flags.files === "release") return "تصمیم تو: آرشیو رها شده.";
    return "تصمیم آرشیو هنوز ثبت نشده.";
  }
  if (spotId === "c") {
    if (flags.phone === "answer") return "به صدای خودت جواب دادی.";
    if (flags.phone === "ignore") return "تماس را قطع کردی، اما جمله را شنیدی.";
    return "تماس آشنا هنوز ثبت نشده.";
  }
  return "";
}

function goalSpot(level: LevelDef, solved: boolean, visited: string[], holding: boolean): string {
  if (solved) return "exit";
  const puzzle = level.puzzle;
  if (puzzle.kind === "visit") return puzzle.spots.find((id) => !visited.includes(id)) ?? "exit";
  if (puzzle.kind === "carry") return holding ? puzzle.targetSpot : puzzle.itemSpot;
  if (puzzle.kind === "hide") return puzzle.goal;
  return level.puzzleSpot;
}

function bearingTo(layout: Layout, hud: FrameInfo, id: string): number {
  const spot = layout.spots.find((item) => item.id === id);
  if (!spot) return 0;
  const dx = spot.x - hud.x;
  const dz = spot.z - hud.z;
  const fx = -Math.sin(hud.yaw);
  const fz = -Math.cos(hud.yaw);
  const rx = Math.cos(hud.yaw);
  const rz = -Math.sin(hud.yaw);
  return Math.atan2(dx * rx + dz * rz, dx * fx + dz * fz);
}

function spotTitle(level: LevelDef, id: string): string {
  if (id === "exit") return solvedLabel(level);
  if (id === "power") return "جعبه برق";
  if (id.startsWith("cover")) return "کمد";
  return level.notes[id]?.title ?? "نقطه قابل بررسی";
}

function solvedLabel(level: LevelDef): string {
  return level.id === 50 ? "در نهایی" : "خروج مرحله";
}

function Stick({ onChange }: { onChange: (x: number, y: number) => void }) {
  const origin = useRef({ x: 0, y: 0 });
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  return (
    <div
      className="stick"
      data-ui
      onPointerDown={(event) => {
        event.currentTarget.setPointerCapture(event.pointerId);
        const rect = event.currentTarget.getBoundingClientRect();
        origin.current = { x: rect.left + rect.width / 2, y: rect.top + rect.height / 2 };
      }}
      onPointerMove={(event) => {
        if (!event.currentTarget.hasPointerCapture(event.pointerId)) return;
        const dx = event.clientX - origin.current.x;
        const dy = event.clientY - origin.current.y;
        const max = 46;
        const cx = Math.max(-max, Math.min(max, dx));
        const cy = Math.max(-max, Math.min(max, dy));
        setKnob({ x: cx, y: cy });
        onChange(cx / max, -cy / max);
      }}
      onPointerUp={(event) => {
        if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId);
        setKnob({ x: 0, y: 0 });
        onChange(0, 0);
      }}
    >
      <div className="knob" style={{ transform: `translate(${knob.x}px, ${knob.y}px)` }} />
    </div>
  );
}

function Journal({ clues, onClose }: { clues: SaveSlot["clues"]; onClose: () => void }) {
  const tabs = Object.entries(CATEGORY_LABEL);
  const [tab, setTab] = useState(tabs[0]?.[0] ?? "docs");
  const list = clues.filter((clue) => clue.category === tab);
  return (
    <div className="overlay">
      <div className="modal-card">
        <h2>دفترچه سرنخ‌ها</h2>
        <div className="journal-tabs">
          {tabs.map(([id, label]) => (
            <button key={id} type="button" className={tab === id ? "btn btn-on" : "btn"} onClick={() => setTab(id)}>
              {label}
            </button>
          ))}
        </div>
        {list.length === 0 ? <p className="hint">در این بخش هنوز چیزی ثبت نشده.</p> : null}
        {list.map((clue) => (
          <article key={clue.id} className="panel">
            <strong>{clue.title}</strong>
            <p className="body-copy">{clue.body}</p>
          </article>
        ))}
        <button type="button" className="btn btn-primary" onClick={onClose}>
          بستن
        </button>
      </div>
    </div>
  );
}

import { createFileRoute } from "@tanstack/react-router";
import { AvidaApp } from "@/components/avida/AvidaApp";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <AvidaApp />;
}
